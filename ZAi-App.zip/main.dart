import 'package:flutter/material.dart';

void main() {
  runApp(const ZAiApp());
}

class ZAiApp extends StatelessWidget {
  const ZAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ZAi – Zahid Assistant Intelligent',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ZAi – Zahid Assistant Intelligent'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Container(
        padding: const EdgeInsets.all(16),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFE3F2FD), Color(0xFFFFF3E0)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),
              const Text(
                '🎓 School Section / اسڪول سيڪشن',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.orange),
              ),
              const SizedBox(height: 8),
              ListTile(
                leading: const Icon(Icons.people, color: Colors.blue),
                title: const Text('Attendance Record / حاضري'),
                onTap: () {},
              ),
              ListTile(
                leading: const Icon(Icons.schedule, color: Colors.blue),
                title: const Text('Exam Schedule / امتحانن جو شيڊول'),
                onTap: () {},
              ),
              ListTile(
                leading: const Icon(Icons.mail, color: Colors.blue),
                title: const Text('Official Letters / سرڪاري خط'),
                onTap: () {},
              ),
              const SizedBox(height: 20),
              const Text(
                '🧠 Personal Section / ذاتي سيڪشن',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.orange),
              ),
              const SizedBox(height: 8),
              ListTile(
                leading: const Icon(Icons.alarm, color: Colors.green),
                title: const Text('Reminders / ياد ڏيارڻا'),
                onTap: () {},
              ),
              ListTile(
                leading: const Icon(Icons.account_balance_wallet, color: Colors.green),
                title: const Text('Expenses / خرچ'),
                onTap: () {},
              ),
              ListTile(
                leading: const Icon(Icons.school, color: Colors.green),
                title: const Text('Personal Goals / ذاتي هدف'),
                onTap: () {},
              ),
              const SizedBox(height: 30),
              Center(
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.chat),
                  label: const Text('Talk to ZAi / زائي سان ڳالهايو'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  ),
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('AI Chat Coming Soon...')),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
