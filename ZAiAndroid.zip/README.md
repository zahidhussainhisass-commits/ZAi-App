# ZAi Android App

Minimal native Android project for ZAi – Zahid Assistant Intelligent.

Build with Android Studio or CI (Codemagic).
